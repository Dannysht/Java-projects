public class Rabbit
{
    private static int x;
    private static int y;
    private boolean direction = true; //Keeps the direction of the rabbit, true is right and up false is left and down

    //Movement method
    public void movement()
    {
        //Checks whether the snake is one square away from the rabbit
        if((Snake.getX() == x && Snake.getY() == y + 1)
                || (Snake.getX() == x && Snake.getY() == y - 1)
                || (Snake.getX() == x + 1 && Snake.getY() == y)
                || (Snake.getX() == x - 1 && Snake.getY() == y)
                || (Snake.getX() == x + 1 && Snake.getY() == y + 1)
                || (Snake.getX() == x + 1 && Snake.getY() == y - 1)
                || (Snake.getX() == x - 1 && Snake.getY() == y + 1)
                || (Snake.getX() == x - 1 && Snake.getY() == y - 1))
        {
            System.out.println("Rabbit: Oh no, please do not eat me!");
        }
        else
        {
            if(Snake.getX() > x || Snake.getY() > y) //Checks if snake's position is higher than rabbit
            {
                direction = false; //Direction change if necessary
            }
            if (Snake.getX() <= x || Snake.getY() <= y) //Checks if snake's position is lower than rabbit
            {
                direction = true; //Direction change if necessary
            }
            if (x == 10 && y == 10) //Checks if the rabbit starts at 10 10
            {
                direction = false; //Direction change if necessary
            }
            if(x == 0 && y == 0) //Checks if rabbit starts at 0 0
            {
                direction = true; //Direction change if necessary
            }
            if (x <= y && x < 10 && direction == true) //Checks direction and boundaries
            {
                ++x;
            }
            else if (x > y && y < 10 && direction == true) //Checks direction and boundaries
            {
                ++y;
            }
            if(x>=y && x > 0 && direction == false) //Checks direction and boundaries
            {
                --x;
            }
            else if(x < y && y > 0 && direction == false) //Checks direction and boundaries
            {
                --y;
            }
            System.out.println("Rabbit: I am the rabbit I am now standing on " + getX() + " " + getY());
            //Checks if rabbit has moved to its death
            if((Snake.getX() == x && Snake.getY() == y + 1)
                    || (Snake.getX() == x && Snake.getY() == y - 1)
                    || (Snake.getX() == x + 1 && Snake.getY() == y)
                    || (Snake.getX() == x - 1 && Snake.getY() == y)
                    || (Snake.getX() == x + 1 && Snake.getY() == y + 1)
                    || (Snake.getX() == x + 1 && Snake.getY() == y - 1)
                    || (Snake.getX() == x - 1 && Snake.getY() == y + 1)
                    || (Snake.getX() == x - 1 && Snake.getY() == y - 1))
            {
                System.out.println("Rabbit: Oh no, please do not eat me!");
            }
        }
    }

    //Constructors
    public Rabbit()
    {
        x = 0 ;
        y = 0 ;
    }

    public Rabbit(int x)
    {
        setX(x);
        y = 0;
    }

    public Rabbit(int x, int y)
    {
        setX(x);
        setY(y);
    }
    //Getters and Setters
    public static int getX()
    {
        return x;
    }

    public static void setX(int xChange)
    {
        if (xChange < 0) //Checks if x is set in boundaries (Validation)
        {
            System.out.println("Rabbit's x cannot be less than 0 changing x to 0!");
            xChange = 0;
        }
        if (xChange > 10) //Checks if x is set in boundaries (Validation)
        {
            System.out.println("Since our grid is only 10x10 changing rabbit's x to 10!");
            xChange = 10;
        }
        x = xChange;
    }

    public static int getY()
    {
        return y;
    }

    public static void setY(int yChange)
    {
        if (yChange < 0) //Checks if y is set in boundaries (Validation)
        {
            System.out.println("Rabbit's y cannot be less than 0 changing y to 0!");
            yChange = 0;
        }
        if (yChange > 10) //Checks if y is set in boundaries (Validation)
        {
            System.out.println("Since our grid is only 10x10 changing rabbit's y to 10!");
            yChange = 10;
        }
        y = yChange;
    }

}

