public class Main
{
    public static void main(String[] args)
    {
        Snake snake = new Snake(8, 10);
        Rabbit rabbit = new Rabbit( 5, 5);
        System.out.println("I am the rabbit I am now standing on " + rabbit.getX() + " " + rabbit.getY());
        System.out.println("I am the snake I am now standing on " + snake.getX() + " " + snake.getY());
        //Loop goes until snake has reached rabbit
        while (snake.getX() != rabbit.getX() ||  snake.getY() != rabbit.getY())
        {
            rabbit.movement();
            snake.movement();
        }
        //After exiting the loop snake eats the rabbit
        System.out.println("Snake: Haha, I am eating you, rabbit!");
    }
}

