public class Main
{
    public static void main(String[] args)
    {
        Bike bikeOne = new Bike();
        Bike bikeTwo = new Bike ("Cross","Red", 120, 25, 155 );
        bikeOne.printBike();
        System.out.println("The product of the height, width and length of the bike is: " + bikeOne.calculateProduct()
                + "\n");
        bikeTwo.printBike();
        System.out.println("The product of the height, width and length of the bike is: " + bikeTwo.calculateProduct()
                + "\n");


    }
}
